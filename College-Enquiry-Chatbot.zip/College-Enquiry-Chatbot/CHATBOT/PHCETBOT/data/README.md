# Install

https://www.python.org/downloads/
Install Python.
then install vscode or Notepad++.
 
Follow the following steps :

1st Step: Firstly, Extract the file
2nd Step: After that, Copy the main project folder
3rd Step: Now, open Terminal/Powershell there. Create and activate virtual environment for python, using below commands:
In Windows Powershell:
4th Step: python -m venv venv
5th Step: venv\scripts\activate
6th Step: Now, install requirements with this command:
          pip install -r requirements.txt
7th Step: python manage.py makemigrations
8th Step: python manage.py migrate
9th Step: python manage.py runserver
Now run the application using below command:
After running, You can access this app on http://127.0.0.1:5000

//////////////////////////////
cd desktop
cd College-Enquiry-Chatbot
python -m venv venv
venv\scripts\activate
pip install -r requirements.txt
cd CHATBOT
cd PHCETBOT
python conversation.py
python bot.py

//////////////////////////////

---LogIn---
Admin

Follow the "info" folder .


---User---

Follow the "info" folder .